"""
CHRONOBOT v 0.28
Date: 24-01-2026
Author: jaybest.nz
"""

import os
import sqlite3
import threading
import time
import random
import json
import datetime
import cv2
import mss
from pynput import mouse, keyboard
from flask import Flask, render_template, jsonify, request, send_from_directory
from waitress import serve

# --- CONFIG ---
DB_NAME = "work_data.db"
DATA_FOLDER = "data_captures"
SCREENSHOT_MIN = 10
SCREENSHOT_MAX = 30
IDLE_TIMEOUT_SECONDS = 300 
POLL_RATE = 1.0

app = Flask(__name__)
# SAFEGUARD: Use a custom filter that handles None gracefully
def json_loads_safe(value):
    try: return json.loads(value) if value else {}
    except: return {}
app.jinja_env.filters['fromjson'] = json_loads_safe

if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)

# --- GLOBAL STATE ---
state = {
    "active": False,
    "session_id": datetime.datetime.now().strftime("%Y%m%d_%H%M%S_DRAFT"),
    "client_id": None,
    "webcam": True,
    "last_input_time": time.time(),
    "is_idle": False,
    "current_task_start": None,
    "key_count": 0,
    "error_key_count": 0
}

# --- DATABASE WRAPPER ---
def query_db(query, args=(), one=False):
    try:
        with sqlite3.connect(DB_NAME) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(query, args)
            rv = cur.fetchall()
            conn.commit()
            return (rv[0] if rv else None) if one else rv
    except Exception as e:
        print(f"DB Error: {e}")
        return None

def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS clients (id INTEGER PRIMARY KEY, name TEXT, email TEXT, rate REAL, gst BOOLEAN)')
        c.execute('''CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            description TEXT,
            size_estimate INTEGER,
            is_completed BOOLEAN DEFAULT 0,
            indent_level INTEGER DEFAULT 0,
            sort_order INTEGER DEFAULT 0,
            created_at TIMESTAMP,
            completed_at TIMESTAMP,
            actual_duration_mins INTEGER DEFAULT 0
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            timestamp TIMESTAMP,
            event_type TEXT, 
            data TEXT 
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS captures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            timestamp TIMESTAMP,
            img_path TEXT,
            cam_path TEXT,
            trigger_type TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            client_id INTEGER,
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            notes TEXT,
            rating INTEGER,
            energy_level INTEGER,
            mood_level INTEGER,
            total_keystrokes INTEGER DEFAULT 0,
            error_keystrokes INTEGER DEFAULT 0,
            is_billable BOOLEAN DEFAULT 1
        )''')
        conn.commit()

init_db()

# --- HELPERS ---
def get_local_time(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_event(type, data_dict=None):
    if not state["session_id"]: return
    query_db("INSERT INTO events (session_id, timestamp, event_type, data) VALUES (?,?,?,?)",
             (state["session_id"], get_local_time(), type, json.dumps(data_dict or {})))

# --- INPUT MONITOR ---
def on_action(*args):
    state["last_input_time"] = time.time()
    if state["is_idle"]: state["is_idle"] = False

def on_press(key):
    state["last_input_time"] = time.time()
    if state["is_idle"]: state["is_idle"] = False
    if state["active"]:
        state["key_count"] += 1
        if key == keyboard.Key.backspace or key == keyboard.Key.delete:
            state["error_key_count"] += 1

def start_input_listeners():
    m_listener = mouse.Listener(on_move=on_action, on_click=on_action)
    k_listener = keyboard.Listener(on_press=on_press)
    m_listener.start()
    k_listener.start()

# --- MONITOR LOOP ---
def take_snapshot(trigger="RANDOM"):
    ts_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    local_time = get_local_time()
    s_name = f"screen_{ts_str}.png"
    c_name = f"cam_{ts_str}.jpg"
    
    try:
        with mss.mss() as sct: sct.shot(mon=-1, output=os.path.join(DATA_FOLDER, s_name))
    except: s_name = None

    cam_ok = False
    if state["webcam"]:
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened(): cap = cv2.VideoCapture(1)
            ret, frame = cap.read()
            if ret:
                cv2.imwrite(os.path.join(DATA_FOLDER, c_name), frame)
                cam_ok = True
            cap.release()
        except: pass

    query_db("INSERT INTO captures (session_id, timestamp, img_path, cam_path, trigger_type) VALUES (?,?,?,?,?)",
             (state["session_id"], local_time, s_name, c_name if cam_ok else None, trigger))

def monitor_loop():
    next_snap = time.time() + random.randint(SCREENSHOT_MIN*60, SCREENSHOT_MAX*60)
    while True:
        if state["active"]:
            if time.time() - state["last_input_time"] > IDLE_TIMEOUT_SECONDS and not state["is_idle"]:
                state["is_idle"] = True
                take_snapshot("IDLE_PAUSE")
                log_event("IDLE_PAUSE", {"duration": "5m+"})
            
            if time.time() > next_snap and not state["is_idle"]:
                take_snapshot("RANDOM")
                next_snap = time.time() + random.randint(SCREENSHOT_MIN*60, SCREENSHOT_MAX*60)
        time.sleep(POLL_RATE)

threading.Thread(target=monitor_loop, daemon=True).start()
start_input_listeners()

# --- ROUTES ---

@app.route('/')
def index(): return render_template('index.html')

@app.route('/api/clients', methods=['GET', 'POST'])
def handle_clients():
    if request.method == 'POST':
        d = request.json
        with sqlite3.connect(DB_NAME) as conn:
            cur = conn.execute("INSERT INTO clients (name, email, rate, gst) VALUES (?,?,?,?)", 
                             (d['name'], d.get('email',''), d.get('rate', 0), d.get('gst', False)))
            return jsonify({"id": cur.lastrowid})
    return jsonify([dict(c) for c in query_db("SELECT * FROM clients")])

@app.route('/api/start_session', methods=['POST'])
def start_session():
    d = request.json
    new_sid = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    state.update({
        "active": True, "session_id": new_sid, "client_id": d.get('client_id'), 
        "webcam": d.get('webcam', True), "current_task_start": time.time(),
        "key_count": 0, "error_key_count": 0
    })
    
    with sqlite3.connect(DB_NAME) as conn:
        conn.execute("INSERT INTO sessions (id, client_id, start_time, is_billable) VALUES (?,?,?,?)",
                     (new_sid, d.get('client_id'), get_local_time(), d.get('is_billable', True)))
        conn.execute("UPDATE tasks SET session_id = ? WHERE session_id LIKE '%_DRAFT'", (new_sid,))
    
    tasks = query_db("SELECT description FROM tasks WHERE session_id = ? ORDER BY sort_order ASC", (new_sid,))
    task_names = [t['description'] for t in tasks]
    
    log_event("SESSION_START", {"tasks": task_names})
    if len(task_names) > 0: log_event("WORKING_ON", {"task": task_names[0]})

    return jsonify({"status": "started", "session_id": new_sid})

@app.route('/api/complete_task', methods=['POST'])
def complete_task():
    d = request.json
    task_id = d['id']
    now = get_local_time()
    
    duration = 0
    if state["current_task_start"]:
        duration = int((time.time() - state["current_task_start"]) / 60)
        if duration < 1: duration = 1 
    
    task = query_db("SELECT * FROM tasks WHERE id=?", (task_id,), one=True)
    if not task: return jsonify({"status": "error"})

    with sqlite3.connect(DB_NAME) as conn:
        conn.execute("UPDATE tasks SET is_completed=1, completed_at=?, actual_duration_mins=? WHERE id=?", 
                     (now, duration, task_id))
        max_sort = conn.execute("SELECT MAX(sort_order) FROM tasks WHERE session_id=?", (state["session_id"],)).fetchone()[0] or 0
        conn.execute("UPDATE tasks SET sort_order=? WHERE id=?", (max_sort+1, task_id))

    log_event("TASK_COMPLETE", {
        "task": task['description'], "estimate": task['size_estimate'], "actual": duration, 
        "diff": duration - (task['size_estimate'] or 0)
    })

    state["current_task_start"] = time.time()
    next_tasks = query_db("SELECT description FROM tasks WHERE session_id=? AND is_completed=0 ORDER BY sort_order ASC", (state["session_id"],))
    if next_tasks: log_event("WORKING_ON", {"task": next_tasks[0]['description']})
        
    return jsonify({"status": "ok"})

@app.route('/api/stop_session', methods=['POST'])
def stop_session():
    d = request.json
    query_db("""
        UPDATE sessions 
        SET end_time=?, notes=?, rating=?, energy_level=?, mood_level=?, total_keystrokes=?, error_keystrokes=? 
        WHERE id=?
    """, (get_local_time(), d.get('notes'), d.get('rating'), d.get('energy'), d.get('mood'), state['key_count'], state['error_key_count'], state["session_id"]))
    
    state["active"] = False
    state["session_id"] = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_DRAFT")
    return jsonify({"status": "stopped"})

@app.route('/api/tasks', methods=['GET','POST'])
def tasks_route():
    sid = state["session_id"]
    if request.method == 'POST':
        d = request.json
        with sqlite3.connect(DB_NAME) as conn:
            max_s = conn.execute("SELECT MAX(sort_order) FROM tasks WHERE session_id=?", (sid,)).fetchone()[0] or 0
            conn.execute("INSERT INTO tasks (session_id, description, size_estimate, sort_order) VALUES (?,?,?,?)",
                         (sid, d['description'], d['size'], max_s+1))
        return jsonify({"status":"added"})
    
    if "_DRAFT" in sid:
        tasks = query_db("SELECT * FROM tasks WHERE session_id LIKE '%_DRAFT' ORDER BY sort_order ASC")
    else:
        tasks = query_db("SELECT * FROM tasks WHERE session_id=? ORDER BY sort_order ASC", (sid,))
        
    return jsonify([dict(t) for t in tasks])

@app.route('/api/update_task_meta', methods=['POST'])
def update_task_meta():
    d = request.json
    query_db("UPDATE tasks SET indent_level = ? WHERE id = ?", (d['indent'], d['id']))
    return jsonify({"status": "updated"})

@app.route('/api/reorder_tasks', methods=['POST'])
def reorder_tasks():
    order_list = request.json 
    with sqlite3.connect(DB_NAME) as conn:
        for index, task_id in enumerate(order_list):
            conn.execute("UPDATE tasks SET sort_order = ? WHERE id = ?", (index, task_id))
    return jsonify({"status": "reordered"})

@app.route('/report')
def report():
    client_id = request.args.get('client_id')
    clients = query_db("SELECT * FROM clients")
    
    # Init empty stats
    stats = {'total_tasks': 0, 'est': 0, 'act': 0, 'billed': 0}
    
    if client_id:
        events = query_db("SELECT 'event' as type, timestamp, event_type as title, data, NULL as img, session_id FROM events JOIN sessions ON events.session_id = sessions.id WHERE sessions.client_id = ?", (client_id,))
        captures = query_db("SELECT 'capture' as type, timestamp, trigger_type as title, NULL as data, img_path as img, cam_path, session_id FROM captures JOIN sessions ON captures.session_id = sessions.id WHERE sessions.client_id = ?", (client_id,))
        timeline = sorted((events or []) + (captures or []), key=lambda x: x['timestamp'])
        
        raw_sessions = query_db("SELECT * FROM sessions WHERE client_id = ? ORDER BY start_time DESC", (client_id,))
        sessions = []
        if raw_sessions:
            for s in raw_sessions:
                s_dict = dict(s)
                try:
                    start = datetime.datetime.strptime(s_dict['start_time'], "%Y-%m-%d %H:%M:%S")
                    end_str = s_dict['end_time']
                    end = datetime.datetime.strptime(end_str, "%Y-%m-%d %H:%M:%S") if end_str else datetime.datetime.now()
                    duration_mins = (end - start).total_seconds() / 60
                    s_dict['duration_mins'] = round(duration_mins, 1)
                    s_dict['billed_hours'] = round(duration_mins / 60, 2) if s_dict['is_billable'] else 0.0
                    total_keys = s_dict['total_keystrokes'] or 0
                    s_dict['kpm'] = int(total_keys / duration_mins) if duration_mins > 0 else 0
                    errors = s_dict['error_keystrokes'] or 0
                    s_dict['error_rate'] = round((errors / total_keys) * 100, 1) if total_keys > 0 else 0.0
                except:
                    s_dict['kpm'] = 0; s_dict['error_rate'] = 0.0; s_dict['billed_hours'] = 0.0
                sessions.append(s_dict)

        tasks = query_db("SELECT tasks.* FROM tasks JOIN sessions ON tasks.session_id = sessions.id WHERE sessions.client_id = ? AND is_completed = 1", (client_id,))
        
        # Calculate stats
        total_est = sum([t['size_estimate'] or 0 for t in tasks])
        total_act = sum([t['actual_duration_mins'] or 0 for t in tasks])
        total_billed = sum([s.get('billed_hours', 0) for s in sessions])
        stats = {'total_tasks': len(tasks), 'est': total_est, 'act': total_act, 'billed': total_billed}
        
        selected_client = next((c for c in clients if str(c['id']) == str(client_id)), None)
        
        return render_template('report.html', 
                               clients=clients, timeline=timeline, tasks=tasks, 
                               selected_client=selected_client, sessions=sessions,
                               stats=stats)
            
    # FIXED: PASSING STATS EVEN WHEN EMPTY
    return render_template('report.html', clients=clients, timeline=[], tasks=[], sessions=[], stats=stats)

@app.route('/data_captures/<path:f>')
def serve_img(f): return send_from_directory(DATA_FOLDER, f)

if __name__ == '__main__':
    os.system('cls' if os.name == 'nt' else 'clear')
    print("      🕵️  CHRONOBOT ENGINE STARTED (WAITRESS)      ")
    serve(app, host='127.0.0.1', port=5000)